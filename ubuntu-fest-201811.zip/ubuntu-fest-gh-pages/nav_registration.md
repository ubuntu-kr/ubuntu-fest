---
layout: page
title: ": Registration"
#icon: <i class="fas fa-ticket-alt"></i><i class="far fa-check-circle"></i>
permalink: /registration/
---

- 참가등록은 Festa.io 를 통하여 진행합니다.
- 참가 등록 가능한 인원은 최대 100명 이며, 선착순 등록 입니다.
- 참가등록을 하셨으나 부득이하게 참석을 못하시는 경우, 등록 취소를 꼭 해주세요.

{% include btn.html url="" label="등록" %}
