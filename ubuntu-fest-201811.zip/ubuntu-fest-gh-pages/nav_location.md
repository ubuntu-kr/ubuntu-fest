---
layout: page
title: "- Location"
icon: <i class="fas fa-map"></i>
permalink: /location/
---
# {{ site.location }}
## - {{ site.address }}
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1606.3585117474738!2d127.3440439635228!3d36.36763261757487!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x35654ba17aa0db65%3A0x8b0fc59c361a5666!2zRGFlamVvbiwgR3VuZy1kb25nLCDstqnrgqjrjIDtlZnqtZAg6rO16rO864yA7ZWZMe2YuOq0gA!5e0!3m2!1sen!2skr!4v1536292652133" width="100%" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>
  ㅤㅤㅤ
       &nbsp;
       &nbsp;
<h3 style="text-align:center">취봉홀 전경 ▼ </h3>


<img src="{{ site.baseurl }}/assets/imgs/CNU-spot.jpg" style="width:100%">
