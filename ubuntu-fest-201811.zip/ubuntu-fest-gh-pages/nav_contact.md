---
layout: page
title: "- Contact"
icon: <i class="fas fa-envelope-open"></i>
permalink: /contact/
---
Ubunu Fest 행사 운영과 관련하여 문의가 있으신 경우 아래 연락처로 연락해 주시기 바랍니다.

- [{{ site.email }}](mailto:korea.ubuntu@gmail.com)
